package nl.th8.presidium.scheduler;

public class DuplicateCallsignException extends Throwable {
}
