package nl.th8.presidium.complaints;

public class InvalidComplaintException extends Throwable {
}
