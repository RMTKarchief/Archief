package nl.th8.presidium.archive;

public class TypeNotFoundException extends Throwable {
}
