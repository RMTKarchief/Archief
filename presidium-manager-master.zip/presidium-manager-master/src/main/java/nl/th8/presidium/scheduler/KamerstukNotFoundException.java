package nl.th8.presidium.scheduler;

public class KamerstukNotFoundException extends Throwable {
}
