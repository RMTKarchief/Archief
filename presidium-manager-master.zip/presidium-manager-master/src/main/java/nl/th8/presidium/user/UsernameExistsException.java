package nl.th8.presidium.user;

public class UsernameExistsException extends Throwable {
    public UsernameExistsException(String s) {

    }
}
